import React from 'react';

const CounterResult = (props)=> {
  return(
    <div> Result : {props.value}</div>
  );
}

export default CounterResult;